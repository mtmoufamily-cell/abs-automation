# ⭐ AB's Studio — Automation

Génération automatique de contenu YouTube + produits Gumroad via GitHub Actions.

## Ce que ça fait

- **Chaque jour à 19h (heure NC)** — génère 1 vidéo par catégorie (11 catégories)
- **Chaque lundi** — génère 1 nouveau produit Gumroad
- **Email récapitulatif** envoyé à mtmoufamily@gmail.com avec tout le contenu prêt

## Catégories générées

### AB's Kids (FR)
- 🦁 Fun Facts animaux
- 🎵 Chansons éducatives
- 😊 Émotions enfants
- 💪 Motivation & Citations
- 🔧 Astuces de la vie
- 😂 Humour Outre-Mer

### AB's Pro (EN)
- ⚡ Electrical Tips
- 🔨 Home Improvement
- 🚿 Plumbing Tips
- 🚗 Car Maintenance
- 🌿 Garden & Outdoor

## Setup — 3 étapes

### Étape 1 — Configurer les secrets GitHub

Dans ton repo GitHub → **Settings → Secrets and variables → Actions → New repository secret**

Ajoute ces 3 secrets :

| Nom | Valeur |
|-----|--------|
| `ANTHROPIC_API_KEY` | Ta clé Anthropic `sk-ant-...` |
| `GUMROAD_ACCESS_TOKEN` | Ta clé Gumroad |
| `RESEND_API_KEY` | Ta clé Resend (voir étape 2) |

### Étape 2 — Créer un compte Resend (email gratuit)

1. Va sur **resend.com** → crée un compte gratuit
2. **API Keys** → Create API Key → copie la clé
3. Ajoute-la dans les secrets GitHub comme `RESEND_API_KEY`

> Resend = 3 000 emails gratuits/mois — largement suffisant

### Étape 3 — Activer GitHub Actions

1. Dans ton repo → onglet **Actions**
2. Si désactivé → clique **"I understand my workflows, go ahead and enable them"**
3. Pour tester maintenant → **Actions → Daily Automation → Run workflow**

## Résultats

Les résultats sont sauvegardés dans `products/latest.json` et dans l'onglet **Actions → Artifacts**.

Tu reçois aussi un email HTML complet avec :
- Tous les scripts vidéo prêts
- Les descriptions YouTube
- Les hashtags par plateforme
- Les boutons directs HeyGen / YouTube / TikTok / Instagram
- Le produit Gumroad du lundi avec description complète

## Coût mensuel

| Service | Coût |
|---------|------|
| GitHub Actions | Gratuit |
| Anthropic API | ~$1/mois (11 vidéos/jour) |
| Resend | Gratuit |
| Gumroad | 10% par vente uniquement |
| **Total** | **~$1/mois** |
